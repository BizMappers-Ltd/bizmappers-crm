<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">

<!-- theme meta -->
<meta name="theme-name" content="quixlab" />

<title>BizMappers</title>
<!-- Favicon icon -->
<link rel="icon" type="../../template/image/png" sizes="16x16" href="../../template/images/favicon.png">
<!-- Pignose Calender -->
<link href="../../template/plugins/pg-calendar/css/pignose.calendar.min.css" rel="stylesheet">
<!-- Chartist -->
<link rel="stylesheet" href="../../template/plugins/chartist/css/chartist.min.css">
<link rel="stylesheet" href="../../template/plugins/chartist-plugin-tooltips/css/chartist-plugin-tooltip.css">
<!-- Custom Stylesheet -->
<link href="../../template/css/style.css" rel="stylesheet">
<link href="../../template/css/style.css" rel="stylesheet">


<script src="https://kit.fontawesome.com/eabba84056.js" crossorigin="anonymous"></script>