<div class="footer">
            <div class="copyright">
                <p>Copyright &copy; Designed & Developed by BizMappers 2024</p>
            </div>
        </div>