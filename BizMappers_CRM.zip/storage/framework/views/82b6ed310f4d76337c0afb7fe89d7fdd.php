<div class="nk-sidebar position-fixed">
    <div class="nk-nav-scroll">
        <ul class="metismenu" id="menu">
            <li>
                <a href="<?php echo e(route('dashboard')); ?>" aria-expanded="false">
                    <i class="icon-speedometer menu-icon"></i><span class="nav-text">Dashboard</span>
                </a>

            </li>


            <li class="mega-menu mega-menu-sm">
                <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                    <i class="fa-regular fa-file"></i><span class="nav-text">Applications</span>
                </a>
                <ul aria-expanded="false">
                    <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'manager' || auth()->user()->role == 'employee'): ?>
                    <li><a href="<?php echo e(route('ad-account-application')); ?>" aria-expanded="false">
                            New
                        </a></li>
                    <?php endif; ?>

                    <?php if(auth()->user()->role == 'customer'): ?>
                    <li><a href="<?php echo e(route('adaccount.adaccount', auth()->user()->id)); ?>" aria-expanded="false">
                            New
                        </a></li>
                    <?php endif; ?>
                    <li><a href="<?php echo e(route('ad-account.index')); ?>">All Applications</a></li>
                    <li><a href="<?php echo e(route('pending-ad-account-application')); ?>">Pending</a></li>
                    <li><a href="<?php echo e(route('approved-ad-account-application')); ?>">Approved</a></li>

                </ul>
            </li>

            <li class="mega-menu mega-menu-sm">
                <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                    <i class="icon-notebook menu-icon"></i><span class="nav-text">Accounts</span>
                </a>
                <ul aria-expanded="false">
                    <?php if(auth()->user()->role == 'customer'): ?>
                    <li><a href="<?php echo e(route('my-account.index')); ?>">My Account</a></li>
                    <?php elseif(auth()->user()->role == 'admin' || auth()->user()->role == 'manager' || auth()->user()->role == 'employee'): ?>
                    <li><a href="<?php echo e(route('my-account.index')); ?>">All Account</a></li>
                    <?php endif; ?>
                </ul>
            </li>

            <li class="mega-menu mega-menu-sm">
                <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                    <i class="fa-solid fa-bolt"></i><span class="nav-text">Refill</span>
                </a>
                <ul aria-expanded="false">
                    <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'employee' || auth()->user()->role == 'manager'): ?>
                    <li><a href="<?php echo e(route('refill-application')); ?>" aria-expanded="false">
                            New
                        </a></li>
                    <?php endif; ?>



                    <!-- new refill for customer -->
                    <?php if(auth()->user()->role == 'customer'): ?>
                    <li><a href="<?php echo e(route('refills.newRefill', auth()->user()->id)); ?>" aria-expanded="false">
                            New
                        </a></li>
                    <?php endif; ?>
                    <!-- *********** -->

                    <li><a href="<?php echo e(route('refills.index')); ?>">All</a></li>
                    <li><a href="<?php echo e(route('refills.pending')); ?>">Pending</a></li>

                </ul>
            </li>
            <?php if(auth()->user()->role == 'admin'): ?>
            <li class="mega-menu mega-menu-sm">
                <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                    <i class="fa-regular fa-building"></i><span class="nav-text">Agencies</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="<?php echo e(route('add-agency')); ?>" aria-expanded="false">
                            New
                        </a></li>
                    <li><a href="<?php echo e(route('all-agency')); ?>">All</a></li>


                </ul>
            </li>
            <?php endif; ?>

            <?php if(auth()->user()->role == 'admin'): ?>
            <li class="mega-menu mega-menu-sm">
                <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                    <i class="fa-solid fa-user-tie"></i><span class="nav-text">Admins</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="<?php echo e(route('register.admin')); ?>" aria-expanded="false">
                            New
                        </a></li>
                    <li><a href="<?php echo e(route('user.admin')); ?>">All</a></li>

                </ul>
            </li>
            <?php endif; ?>

            <?php if(auth()->user()->role == 'admin'): ?>
            <li class="mega-menu mega-menu-sm">
                <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                    <i class="fa-regular fa-user"></i><span class="nav-text">Managers</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="<?php echo e(route('register.manager')); ?>" aria-expanded="false">
                            New
                        </a></li>
                    <li><a href="<?php echo e(route('user.manager')); ?>">All</a></li>

                </ul>
            </li>
            <?php endif; ?>

            <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'manager' ): ?>
            <li class="mega-menu mega-menu-sm">
                <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                    <i class="fa-regular fa-user"></i><span class="nav-text">Employees</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="<?php echo e(route('register.employee')); ?>" aria-expanded="false">
                            New
                        </a></li>
                    <li><a href="<?php echo e(route('user.employee')); ?>">All</a></li>

                </ul>
            </li>
            <?php endif; ?>



            <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'manager' || auth()->user()->role == 'employee'): ?>
            <li class="mega-menu mega-menu-sm">
                <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                    <i class="fa-solid fa-users"></i></i><span class="nav-text">Clients</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="<?php echo e(route('register')); ?>" aria-expanded="false">
                            New
                        </a></li>
                    <li><a href="<?php echo e(route('user.client')); ?>">All</a></li>

                </ul>
            </li>
            <?php endif; ?>




            <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'manager'): ?>
            <li class="mega-menu mega-menu-sm">
                <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                    <i class="fa fa-money"></i></i><span class="nav-text">Deposit</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="<?php echo e(route('deposit.create')); ?>" aria-expanded="false">
                            New
                        </a></li>
                    <li><a href="<?php echo e(route('deposits.index')); ?>">All</a></li>
                    <li><a href="<?php echo e(route('averageUsdRate')); ?>">Monthly Avarage USD Rate</a></li>

                </ul>
            </li>
            <?php endif; ?>


            <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'manager' ): ?>
            <li class="mega-menu mega-menu-sm">
                <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                    <i class="fa-solid fa-chart-simple"></i><span class="nav-text">Report</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="<?php echo e(route('monthlyReport.index')); ?>" aria-expanded="false">
                            Ad Account Report
                        </a>
                    </li>
                    <li><a href="<?php echo e(route('agency.showAvailableMonths')); ?>">Agency Report</a></li>
                    <li><a href="<?php echo e(route('deposits.report.dateRange')); ?>">Deposit Report</a></li>
                    <li><a href="<?php echo e(route('dailyReport.index')); ?>">Daily Calculation</a></li>
                </ul>
            </li>
            <?php endif; ?>

            <?php if(auth()->user()->role == 'admin'): ?>
            <li>
                <a href="<?php echo e(route('settings')); ?>" aria-expanded="false">
                    <i class="fa-solid fa-gear"></i><span class="nav-text">Settings</span>
                </a>
            </li>
            <?php endif; ?>

        </ul>
    </div>
</div><?php /**PATH C:\xampp\htdocs\BizMappers_CRM\resources\views/template/home/layouts/sidebar.blade.php ENDPATH**/ ?>