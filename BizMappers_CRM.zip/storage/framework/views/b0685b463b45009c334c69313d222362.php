<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'inline-flex w-100 btn btn-primary tracking-widest'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\xampp\htdocs\BizMappers_CRM\resources\views/components/primary-button.blade.php ENDPATH**/ ?>