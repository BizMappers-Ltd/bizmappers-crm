<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('template.home.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('template.home.custom_styles.custom_style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->


    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!-- navbar start -->
        <?php echo $__env->make('template.home.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- navbar end -->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php echo $__env->make('template.home.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--**********************************
            Sidebar end
        ***********************************-->



        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">

            <div class="container-fluid mt-3">
                <div class="row">
                    <div class="col-lg-3 col-sm-6">
                        <div class="d-flex align-items-center custom-card">
                            <div class="w-100 p-3">
                                <ul>
                                    <li>
                                        <h6 class="text-white">Total Application: <span class="font-lg"><?php echo e($allApplication); ?></span></h6>
                                    </li>
                                    <li class="bg-transparent border-0">
                                        <h6 class="text-white">Pending Application: <span class="font-lg"><?php echo e($pendingApplication); ?></span></h6>
                                    </li>
                                    <li class="bg-transparent border-0">
                                        <h6 class="text-white">Total Ad Account: <span class="font-lg"><?php echo e($allAdAccount); ?></span></h6>
                                    </li>

                                </ul>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <div class="d-flex align-items-center custom-card">
                            <div class=" w-100 p-3">
                                <ul>
                                    <li>
                                        <h6 class="text-white">Current Month Refill: <span class="font-lg">$<?php echo e($thisMonthRefill); ?></span></h6>
                                    </li>
                                    <li>
                                        <h6 class="text-white">Last 7 Days Refill: <span class="font-lg">$<?php echo e($lastSevenDaysRefill); ?></span></h6>
                                    </li>
                                    <li>
                                        <h6 class="text-white">Refill Request: <span class="font-lg">$<?php echo e($pendingRefillAmount); ?> (<?php echo e($pendingRefillCount); ?>)</span></h6>
                                    </li>
                                </ul>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="d-flex align-items-center custom-card">
                            <div class=" w-100 p-3">
                                <ul>
                                    <li>
                                        <h6 class="text-white">Current Month Deposit: <span class="font-lg">$<?php echo e($totalDeposit); ?></span></h6>
                                    </li>
                                    <li>
                                        <h6 class="text-white">Current Month Average Rate: <span class="font-lg">৳<?php echo e(number_format($averageRate, 2)); ?></span></h6>
                                    </li>
                                    <li class="     
                                    ">
                                        <h6 class="text-white">Balance: <span class="font-lg"></span></h6>
                                    </li>
                                </ul>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2 col-sm-6">
                        <div class="btn-group-vertical w-100">
                            <a href="#" class="btn btn-primary text-white my-2 py-2 rounded" data-toggle="modal" data-target="#refillModal">New Refill</a>
                            <a href="#" class="btn btn-success text-white mb-2 py-2 rounded" data-toggle="modal" data-target="#depositModal">Add Deposit</a>
                            <a href="<?php echo e(route('ad-account-application')); ?>" class="btn btn-secondary text-white py-2 rounded">New Application</a>

                        </div>
                    </div>
                </div>

                <div class="row mt-4">
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <h4 class="card-title mr-4 mt-2">Refill History</h4>

                                    <a href="<?php echo e(route('refills.index')); ?>">
                                        <button class="btn btn-sm btn-secondary text-white">See All</button>
                                    </a>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-xs mb-0">
                                        <thead>
                                            <tr>
                                                <th>Refill Date</th>
                                                <th>Ad Account Name</th>
                                                <th>Refill Amount ($)</th>
                                                <th>Payment Method</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $refills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $refill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($refill->created_at->format('j F Y')); ?></td>
                                                <td>
                                                    <span><?php echo e($refill->adAccount->ad_acc_name); ?></span><br>
                                                    <span class="font-sm mt-1"><?php echo e($refill->adAccount->ad_acc_id); ?></span>
                                                </td>
                                                <td><?php echo e($refill->amount_dollar); ?></td>
                                                <td><?php echo e($refill->payment_method); ?></td>
                                                <td>
                                                    <?php if($refill->status == 'pending'): ?>
                                                    <span class="badge custom-badge-info">Pending</span>
                                                    <?php endif; ?>



                                                    <?php if($refill->status == 'approved'): ?>
                                                    <span class="badge custom-badge-success">Approved</span>
                                                    <?php endif; ?>

                                                    <?php if($refill->status == 'rejected'): ?>
                                                    <span class="badge badge-danger px-3 py-1">Rejected</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Pie chart</h4>
                                <canvas id="pieChart" width="500" height="250"></canvas>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-5">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <h4 class="card-title mr-4 mt-2">Pending Applications</h4>

                                    <a href="<?php echo e(route('pending-ad-account-application')); ?>">
                                        <button class="btn btn-sm btn-secondary text-white">See All</button>
                                    </a>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-xs mb-0 font-sm">
                                        <thead>
                                            <tr>
                                                <th>Client</th>
                                                <th>Ad Acc.</th>
                                                <th>BM Id</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $adAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adAccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($adAccount->client->name); ?></td>
                                                <td>
                                                    <span><?php echo e($adAccount->ad_acc_name); ?></span><br>
                                                    <span class="font-sm mt-1"><?php echo e($adAccount->ad_acc_id); ?></span>
                                                </td>
                                                <td><?php echo e($adAccount->bm_id); ?></td>

                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-7">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <h4 class="card-title mr-4 mt-2">Pending Refills</h4>

                                    <a href="<?php echo e(route('refills.pending')); ?>">
                                        <button class="btn btn-sm btn-secondary text-white">See All</button>
                                    </a>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-xs mb-0 font-sm">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Ad Acc.</th>
                                                <th>Amount ($)</th>
                                                <th>Method</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $pendingRefills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendingRefill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($pendingRefill->created_at->format('j F Y')); ?></td>
                                                <td>
                                                    <span><?php echo e($pendingRefill->adAccount->ad_acc_name); ?></span><br>
                                                    <span class="font-sm mt-1"><?php echo e($pendingRefill->adAccount->ad_acc_id); ?></span>
                                                </td>
                                                <td><?php echo e($pendingRefill->amount_dollar); ?></td>
                                                <td><?php echo e($pendingRefill->payment_method); ?></td>
                                                <td>
                                                    <span>
                                                        <form action="<?php echo e(route('refill.approve', $pendingRefill->id)); ?>" method="POST" style="display:inline-block;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PUT'); ?>
                                                            <button type="submit" class="btn btn-sm bg-transparent" data-toggle="tooltip" data-placement="top" title="Approve"><i class="fa-solid fa-check"></i></button>
                                                        </form>
                                                        <form action="<?php echo e(route('refill.reject', $pendingRefill->id)); ?>" method="POST" style="display:inline-block;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PUT'); ?>
                                                            <button type="submit" class="btn btn-sm bg-transparent" data-toggle="tooltip" data-placement="top" title="Reject"><i class="fa-solid fa-xmark"></i></button>
                                                        </form>

                                                    </span>
                                                </td>

                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>


            </div>
            <!-- #/ container -->
        </div>
        <!--**********************************
            Content body end
        ***********************************-->


        <!--**********************************
            Footer start
        ***********************************-->
        <?php echo $__env->make('template.home.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--**********************************
            Footer end
        ***********************************-->




        <!-- Refill Modal -->
        <div class="modal fade" id="refillModal" tabindex="-1" role="dialog" aria-labelledby="refillModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="refillModalLabel">New Refill</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('refill.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div>
                                <label class="col-form-label">Client Name:</label>
                                <select id="client-select" name="client_id" class="form-control rounded">
                                    <option>Select</option>
                                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div>
                                <label class="col-form-label">Ad Account Name:</label>
                                <select id="ad-account-select" name="ad_account_id" class="form-control rounded">
                                    <option>Select</option>
                                </select>
                            </div>

                            <div>
                                <label class="col-form-label">Dollar Rate:</label>
                                <input id="dollar-rate-input" type="text" placeholder="Dollar Rate" class="form-control rounded" readonly>
                            </div>

                            <div>
                                <label class="col-form-label">Amount:</label><br>

                                <div class="d-flex justify-content-between">
                                    <div class="w-50 mr-2">
                                        <input id="taka-input" type="text" name="amount_taka" placeholder="Taka" class="form-control rounded">
                                    </div>
                                    <div class="w-50">
                                        <input id="dollar-input" type="text" name="amount_dollar" placeholder="Dollar" class="form-control rounded">
                                    </div>
                                </div>
                            </div>

                            <div>
                                <label class="col-form-label">Payment Method</label>
                                <select id="payment_method" name="payment_method" class="form-control rounded">
                                    <option>Select</option>
                                    <?php $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentMethod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($paymentMethod->value); ?>" data-details="<?php echo e($paymentMethod->details); ?>"><?php echo e($paymentMethod->value); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div id="details" class="d-none">
                                <p class="col-form-label font-bold">Payment Method Details: </p>
                                <p id="payment_details"></p>
                            </div>

                            <div>
                                <label class="col-form-label">Transaction Id:</label>
                                <input type="text" name="transaction_id" placeholder="Transaction Id" class="form-control rounded">
                            </div>

                            <div>
                                <label class="col-form-label">Date</label>
                                <input type="date" name="new_date" class="form-control rounded w-50">
                            </div>

                            <div class="mt-2">
                                <label class="col-form-label">Screenshot:</label>
                                <div class="custom-file">
                                    <input type="file" id="screenshot" name="screenshot" class="custom-file-input">
                                    <label class="custom-file-label">Choose file</label>
                                </div>
                            </div>

                            <div class="d-flex justify-content-end mt-4">
                                <input type="submit" name="submit" value="Refill" class="btn btn-primary">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <!-- Deposit Modal -->
        <div class="modal fade" id="depositModal" tabindex="-1" role="dialog" aria-labelledby="depositModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="depositModalLabel">Add Deposit</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('deposit.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div>
                                <label class="col-form-label">Vendor Name</label>
                                <select name="name" class="form-control rounded">
                                    <option>Select</option>
                                    <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($vendor->value); ?>"><?php echo e($vendor->value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div>
                                <label class="col-form-label">Amount (USD):</label>
                                <input type="number" step="0.01" name="amount_usd" placeholder="Amount (USD)" class="form-control rounded" required>
                            </div>

                            <div>
                                <label class="col-form-label">Rate (BDT):</label>
                                <input type="number" step="0.01" name="rate_bdt" placeholder="Rate (BDT)" class="form-control rounded" required>
                            </div>

                            <div class="d-flex justify-content-end mt-4">
                                <input type="submit" name="submit" value="Create Deposit" class="btn btn-primary">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <?php echo $__env->make('template.home.layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('template.home.custom_scripts.refill_application_script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        var ctx = document.getElementById("pieChart");
        ctx.height = 450;
        var myChart = new Chart(ctx, {
            type: 'pie',
            data: {
                datasets: [{
                    data: [<?php echo e($refilledAdAccount); ?>, <?php echo e($nonRefilledAdAccount); ?>],
                    backgroundColor: [
                        "rgba(117, 113, 249,0.9)",
                        "rgba(255, 82, 82, 1)"
                    ]

                }],
                labels: [
                    "Refilled",
                    "Non-refilled",
                ]
            },
            options: {
                responsive: true
            }
        });
    </script>

</body>

</html><?php /**PATH C:\xampp\htdocs\BizMappers_CRM\resources\views/template/home/index.blade.php ENDPATH**/ ?>