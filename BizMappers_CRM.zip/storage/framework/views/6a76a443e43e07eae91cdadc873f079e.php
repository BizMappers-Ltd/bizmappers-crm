<script src="../../template/plugins/common/common.min.js"></script>
<script src="../../template/js/custom.min.js"></script>
<script src="../../template/js/settings.js"></script>
<script src="../../template/js/gleek.js"></script>
<script src="../../template/js/styleSwitcher.js"></script>

<!-- Chartjs -->
<script src="../../template/plugins/chart.js/Chart.bundle.min.js"></script>
<!-- Circle progress -->
<script src="../../template/plugins/circle-progress/circle-progress.min.js"></script>
<!-- Datamap -->
<script src="../../template/plugins/d3v3/index.js"></script>
<script src="../../template/plugins/topojson/topojson.min.js"></script>
<script src="../../template/plugins/datamaps/datamaps.world.min.js"></script>
<!-- Morrisjs -->
<script src="../../template/plugins/raphael/raphael.min.js"></script>
<script src="../../template/plugins/morris/morris.min.js"></script>
<!-- Pignose Calender -->
<script src="../../template/plugins/moment/moment.min.js"></script>
<script src="../../template/plugins/pg-calendar/js/pignose.calendar.min.js"></script>
<!-- ChartistJS -->
<script src="../../template/plugins/chartist/js/chartist.min.js"></script>
<script src="../../template/plugins/chartist-plugin-tooltips/js/chartist-plugin-tooltip.min.js"></script>
<script src="./plugins/chart.js/Chart.bundle.min.js"></script>


<script src="../../template/js/dashboard/dashboard-1.js"></script><?php /**PATH C:\xampp\htdocs\BizMappers_CRM\resources\views/template/home/layouts/scripts.blade.php ENDPATH**/ ?>