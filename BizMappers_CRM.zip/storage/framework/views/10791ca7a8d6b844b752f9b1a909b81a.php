<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('template.home.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('template.home.custom_styles.custom_style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>

    <?php echo $__env->make('template.home.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('template.home.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="content-body">
        <div class="container-fluid">

            <div class="row text-black">
                <div class="col-7">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex align-items-center justify-content-between mb-3">
                                <h4 class="card-title mr-4 mt-2">Detailed refill information of
                                    <?php echo e($refill->adAccount->ad_acc_name); ?>

                                </h4>
                                <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'manager'): ?>
                                <a href="<?php echo e(route('refills.edit', $refill->id)); ?>">
                                    <button class="btn btn-sm btn-secondary text-white">Edit Info<i class="fa fa-pencil color-muted m-r-5 ml-2"></i></button>
                                </a>
                                <?php endif; ?>
                            </div>

                            <div class="row">
                                <b class="col-4">Amount (Taka):</b>
                                <p class="col-8"><?php echo e($refill->amount_taka); ?></p>
                            </div>
                            <div class="row">
                                <b class="col-4">Amount (Dollar):</b>
                                <p class="col-8"><?php echo e($refill->amount_dollar); ?></p>
                            </div>
                            <div class="row">
                                <b class="col-4">Payment Method:</b>
                                <p class="col-8"><?php echo e($refill->payment_method); ?></p>
                            </div>
                            <div class="row">
                                <b class="col-4">Transaction ID:</b>
                                <p class="col-8"><?php echo e($refill->transaction_id); ?></p>
                            </div>
                            <div class="row">
                                <b class="col-4">Status:</b>
                                <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'manager' || auth()->user()->role == 'employee'): ?>

                                <form id="updateStatusForm_<?php echo e($refill->id); ?>" action="<?php echo e(route('refills.updateStatus', $refill->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <select name="status" class="form-select-sm custom-status" style="width: 90px;" onchange="updateStatus(<?php echo e($refill->id); ?>, this.value)">
                                        <option value="pending" <?php echo e($refill->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                        <option value="approved" <?php echo e($refill->status == 'approved' ? 'selected' : ''); ?>>Approved</option>
                                        <option value="rejected" <?php echo e($refill->status == 'rejected' ? 'selected' : ''); ?>>Rejected</option>
                                    </select>
                                </form>
                                <?php elseif(auth()->user()->role == 'customer'): ?>
                                <?php if($refill->status == 'pending'): ?>
                                <span class="badge custom-badge-info">Pending</span>
                                <?php endif; ?>

                                <?php if($refill->status == 'approved'): ?>
                                <span class="badge custom-badge-success">Approved</span>
                                <?php endif; ?>

                                <?php if($refill->status == 'rejected'): ?>
                                <span class="badge badge-danger px-3 py-1">Rejected</span>
                                <?php endif; ?>
                                <?php endif; ?>
                            </div>

                            <?php if($refill->screenshot): ?>
                            <div class="row">
                                <b class="col-4">Screenshot:</b><br>
                            </div>
                            <img src="<?php echo e(asset('storage/' . $refill->screenshot)); ?>" height="1050px" width="350px" alt="Screenshot" class="img-fluid">
                            <?php endif; ?>

                        </div>
                    </div>
                </div>

                <div class="col-5 font-sm">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-5">Ad Account Information</h4>

                            <div class="row">
                                <b class="col-5">Client Name:</b>
                                <p class="col-7 fs-4"><?php echo e($refill->client->name); ?></p>
                            </div>
                            <div class="row">
                                <b class="col-5">Ad Account Name:</b>
                                <p class="col-7 fs-4"><?php echo e($refill->adAccount->ad_acc_name); ?></p>
                            </div>
                            <div class="row">
                                <b class="col-5">Business Name:</b>
                                <p class="col-7 fs-4"><?php echo e($refill->client->business_name); ?></p>
                            </div>
                            <div class="row">
                                <b class="col-5">BM Id:</b>
                                <p class="col-7 fs-4"><?php echo e($refill->adAccount->bm_id); ?></p>
                            </div>

                        </div>
                    </div>
                </div>

            </div>


            <a href="<?php echo e(route('refills.index')); ?>" class="btn btn-sm btn-secondary text-white mt-3">Back</a>
        </div>
    </div>

    <?php echo $__env->make('template.home.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('template.home.layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        function updateStatus(refillId, status) {
            $.ajax({
                url: '/refills/' + refillId + '/status',
                type: 'PATCH',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    status: status
                },
                success: function(response) {
                    alert('Status updated successfully.');
                },
                error: function(xhr) {
                    alert('An error occurred while updating the status.');
                }
            });
        }
    </script>

</body>

</html><?php /**PATH C:\xampp\htdocs\BizMappers_CRM\resources\views/template/home/refill_application/show.blade.php ENDPATH**/ ?>