<div class="footer">
            <div class="copyright">
                <p>Copyright &copy; Designed & Developed by BizMappers 2024</p>
            </div>
        </div><?php /**PATH C:\xampp\htdocs\BizMappers_CRM\resources\views/template/home/layouts/footer.blade.php ENDPATH**/ ?>