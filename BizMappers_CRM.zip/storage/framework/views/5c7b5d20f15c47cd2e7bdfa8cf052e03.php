<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('template.home.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('template.home.custom_styles.custom_style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>


    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!-- navbar start -->
        <?php echo $__env->make('template.home.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- navbar end -->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php echo $__env->make('template.home.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">

            <div class="p-4">
                <div class="card">
                    <div class="card-body">
                        <h2 class="card-title">Date Wise Ad Account Report</h2>

                        <div>


                            <form action="<?php echo e(route('adAccounts.report.generate')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="row mb-3">
                                    <div class="col-md-5">
                                        <div class="input-group date" id="startDatePicker">
                                            <input type="text" class="form-control" name="start_date" placeholder="Start Date" required>
                                            <span class="input-group-addon">
                                                <i class="glyphicon glyphicon-calendar"></i>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="input-group date" id="endDatePicker">
                                            <input type="text" class="form-control" name="end_date" placeholder="End Date" required>
                                            <span class="input-group-addon">
                                                <i class="glyphicon glyphicon-calendar"></i>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <button type="submit" class="btn btn-primary">Generate Report</button>
                                    </div>
                                </div>
                            </form>

                            <?php if(isset($report)): ?>
                            <div class="mt-5">
                                <h5>Report from <?php echo e(\Carbon\Carbon::parse($startDate)->format('d F Y')); ?> to <?php echo e(\Carbon\Carbon::parse($endDate)->format('d F Y')); ?></h5>

                                <h5>Total Income: ৳ <?php echo e($refills->sum('income_tk')); ?></h5>
                            </div>

                            <div class="table-responsive text-nowrap mt-3">

                                <table class="table table-bordered table-striped verticle-middle" id="refillTable">
                                    <thead>
                                        <tr>
                                            <th scope="col">Ad Account</th>
                                            <th scope="col">Total Refill (tk)</th>
                                            <th scope="col">Total Refill (usd)</th>
                                            <th scope="col">Income (tk)</th>
                                            <th scope="col">Dollar Rate</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $refills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $refill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($refill->refill_act_taka)): ?>
                                        <tr>
                                            <td>
                                                <span><?php echo e($refill->adAccount->ad_acc_name); ?></span><br>
                                                <span class="font-sm mt-1">ID: <?php echo e($refill->adAccount->ad_acc_id); ?></span>
                                            </td>
                                            <td>৳ <?php echo e($refill->total_refill_taka); ?></td>
                                            <td>$ <?php echo e($refill->total_refill_dollar); ?></td>
                                            <td>৳ <?php echo e($refill->refill_taka - $refill->refill_act_taka); ?></td>
                                            <td>$ <?php echo e($refill->adAccount->dollar_rate); ?></td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php if(isset($refill->refill_act_usd)): ?>
                                        <tr>
                                            <td>
                                                <span><?php echo e($refill->adAccount->ad_acc_name); ?></span><br>
                                                <span class="font-sm mt-1">ID: <?php echo e($refill->adAccount->ad_acc_id); ?></span>
                                            </td>
                                            <td>৳ <?php echo e($refill->total_refill_taka); ?></td>
                                            <td>$ <?php echo e($refill->total_refill_dollar); ?></td>
                                            <td>৳ <?php echo e($refill->refill_taka - $refill->refill_act_usd * $report->average_rate); ?></td>
                                            <td>$ <?php echo e($refill->adAccount->dollar_rate); ?></td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php if(!isset($refill->refill_act_taka) && !isset($refill->refill_act_usd)): ?>
                                        <tr>
                                            <td>
                                                <span><?php echo e($refill->adAccount->ad_acc_name); ?></span><br>
                                                <span class="font-sm mt-1">ID: <?php echo e($refill->adAccount->ad_acc_id); ?></span>
                                            </td>
                                            <td>৳ <?php echo e($refill->total_refill_taka); ?></td>
                                            <td>$ <?php echo e($refill->total_refill_dollar); ?></td>
                                            <td>৳ <?php echo e($refill->refill_taka - $refill->refill_usd * $report->average_rate); ?></td>
                                            <td>$ <?php echo e($refill->adAccount->dollar_rate); ?></td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?>





                        </div>

                        <!-- Button to trigger modal -->
                        <button type="button" class="btn btn-sm text-white btn-secondary" data-toggle="modal" data-target="#monthlyReportModal">
                            Monthly Report
                        </button>

                    </div>
                </div>
            </div>



            <!-- Modal -->
            <div class="modal fade" id="monthlyReportModal" tabindex="-1" role="dialog" aria-labelledby="monthlyReportModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="monthlyReportModalLabel">Month Wise Ad Account Report</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="table-responsive text-nowrap">
                                <table class="table table-bordered table-striped verticle-middle">
                                    <thead>
                                        <tr>
                                            <th>Year</th>
                                            <th>Month</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $monthsWithData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($month->year); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::create()->month($month->month)->translatedFormat('F')); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('monthlyReport.monthlyReportDetail', ['year' => $month->year, 'month' => $month->month])); ?>" class="btn btn-sm btn-primary">View Report</a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-sm text-white btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>


            <!-- #/ container -->
        </div>
        <!--**********************************
            Content body end
        ***********************************-->


        <!--**********************************
            Footer start
        ***********************************-->
        <?php echo $__env->make('template.home.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--**********************************
            Footer end
        ***********************************-->
    </div>


    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <?php echo $__env->make('template.home.layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#startDatePicker').datepicker({
                format: 'yyyy-mm-dd',
                autoclose: true
            });
            $('#endDatePicker').datepicker({
                format: 'yyyy-mm-dd',
                autoclose: true
            });
        });
    </script>

</body>

</html><?php /**PATH C:\xampp\htdocs\BizMappers_CRM\resources\views/template/home/ad_account_report/index.blade.php ENDPATH**/ ?>