<?php $__currentLoopData = $refills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $refill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($refill->created_at->format('j F Y  g:i a')); ?></td>
    <td><?php echo e($refill->adAccount->ad_acc_name); ?></td>
    <td><?php echo e($refill->adAccount->dollar_rate); ?></td>
    <td><?php echo e($refill->amount_dollar); ?></td>
    <td><?php echo e($refill->amount_taka); ?></td>
    <td><?php echo e($refill->payment_method); ?></td>
    <td><?php echo e($refill->assign); ?></td>
    <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'manager' || auth()->user()->role == 'employee'): ?>
    <td class="text-center">
        <?php if($refill->sent_to_agency == 0 && $refill->payment_method != 'Transferred'): ?>
        <form id="sendToAgencyForm_<?php echo e($refill->id); ?>" style="display:inline-block;">
            <?php echo csrf_field(); ?>
            <button type="button" class="btn btn-sm btn-primary" onclick="sendToAgency(<?php echo e($refill->id); ?>)">
                Send to Agency
            </button>
        </form>
        <?php else: ?>
        <span class="badge custom-badge-success" id="buttonText_<?php echo e($refill->id); ?>">Sent</span>
        <?php endif; ?>
    </td>
    <?php endif; ?>
    <td>
        <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'manager' || auth()->user()->role == 'employee'): ?>
        <form id="updateStatusForm_<?php echo e($refill->id); ?>" action="<?php echo e(route('refills.updateStatus', $refill->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <select name="status" class="form-select-sm custom-status" style="width: 90px;" onchange="updateStatus(<?php echo e($refill->id); ?>, this.value)">
                <option value="pending" <?php echo e($refill->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                <option value="approved" <?php echo e($refill->status == 'approved' ? 'selected' : ''); ?>>Approved</option>
                <option value="rejected" <?php echo e($refill->status == 'rejected' ? 'selected' : ''); ?>>Rejected</option>
            </select>
        </form>
        <?php elseif(auth()->user()->role == 'customer'): ?>
        <?php if($refill->status == 'pending'): ?>
        <span class="badge custom-badge-info">Pending</span>
        <?php endif; ?>
        <?php if($refill->status == 'approved'): ?>
        <span class="badge custom-badge-success">Approved</span>
        <?php endif; ?>
        <?php if($refill->status == 'rejected'): ?>
        <span class="badge badge-danger px-3 py-1">Rejected</span>
        <?php endif; ?>
        <?php endif; ?>
    </td>
    <td>
        <span class="d-flex align-items-center">
            <a href="<?php echo e(route('refills.show', $refill->id)); ?>" data-toggle="tooltip" data-placement="top" title="View">
                <i class="fa fa-eye color-muted m-r-5"></i>
            </a>
            <?php if(auth()->user()->role == 'admin' || auth()->user()->role == 'manager'): ?>
            <a href="<?php echo e(route('refills.edit', $refill->id)); ?>" data-toggle="tooltip" data-placement="top" title="Edit">
                <i class="fa fa-pencil color-muted m-r-5 ml-3"></i>
            </a>
            <?php endif; ?>
            <?php if(auth()->user()->role == 'admin'): ?>
            <div class="basic-dropdown ml-2">
                <div class="dropdown">
                    <i class="fa-solid fa-ellipsis btn btn-sm" data-toggle="dropdown"></i>
                    <div class="dropdown-menu">
                        <a class="dropdown-item">
                            <form action="<?php echo e(route('refills.destroy', $refill->id)); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this Refill Application?')">Delete</button>
                            </form>
                        </a>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </span>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if($refills->hasMorePages()): ?>
<tr>
    <td colspan="10" class="text-center">
        <button class="btn btn-primary load-more" data-page="<?php echo e($refills->currentPage() + 1); ?>">Load More</button>
    </td>
</tr>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\BizMappers_CRM\resources\views/template/home/refill_application/filtered_data.blade.php ENDPATH**/ ?>