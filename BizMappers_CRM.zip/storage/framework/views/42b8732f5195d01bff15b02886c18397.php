<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('template.home.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('template.home.custom_styles.custom_style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>


    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!-- navbar start -->
        <?php echo $__env->make('template.home.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- navbar end -->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php echo $__env->make('template.home.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">

            <div class="p-4">
                <div class="card">
                    <div class="card-body">
                        <div>
                            <h4 class="card-title mr-4 mt-2">Monthly Report of Ad Account for <?php echo e(\Carbon\Carbon::create()->month($month)->translatedFormat('F')); ?> <?php echo e($year); ?></h4>
                            
                            <h5>Total Income: ৳ <?php echo e(number_format($refills->sum('income_tk'), 2)); ?></h5>

                            <a href="<?php echo e(route('adAccounts.report.pdf', ['year' => $year, 'month' => $month])); ?>" class="btn btn-sm btn-primary mb-3">Download PDF</a>

                            <div class="table-responsive text-nowrap mt-3">

                                <table class="table table-bordered table-striped verticle-middle" id="refillTable">
                                    <thead>
                                        <tr>
                                            <th scope="col">Ad Account</th>
                                            <th scope="col">Total Refill (tk)</th>
                                            <th scope="col">Total Refill (usd)</th>
                                            <th scope="col">Income (tk)</th>
                                            <th scope="col">Dollar Rate</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $refills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $refill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($refill->refill_act_taka)): ?>
                                        <tr>
                                            <td>
                                                <span><?php echo e($refill->adAccount->ad_acc_name); ?></span><br>
                                                <span class="font-sm mt-1">ID: <?php echo e($refill->adAccount->ad_acc_id); ?></span>
                                            </td>
                                            <td>৳ <?php echo e($refill->total_refill_taka); ?></td>
                                            <td>$ <?php echo e($refill->total_refill_dollar); ?></td>
                                            <td>৳ <?php echo e($refill->refill_taka - $refill->refill_act_taka); ?></td>
                                            <td><?php echo e($refill->adAccount->dollar_rate); ?></td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php if(isset($refill->refill_act_usd)): ?>
                                        <tr>
                                            <td>
                                                <span><?php echo e($refill->adAccount->ad_acc_name); ?></span><br>
                                                <span class="font-sm mt-1">ID: <?php echo e($refill->adAccount->ad_acc_id); ?></span>
                                            </td>
                                            <td>৳ <?php echo e($refill->total_refill_taka); ?></td>
                                            <td>$ <?php echo e($refill->total_refill_dollar); ?></td>
                                            <td>৳ <?php echo e($refill->refill_taka - $refill->refill_act_usd * $averageRate); ?></td>
                                            <td><?php echo e($refill->adAccount->dollar_rate); ?></td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php if(!isset($refill->refill_act_taka) && !isset($refill->refill_act_usd)): ?>
                                        <tr>
                                            <td>
                                                <span><?php echo e($refill->adAccount->ad_acc_name); ?></span><br>
                                                <span class="font-sm mt-1">ID: <?php echo e($refill->adAccount->ad_acc_id); ?></span>
                                            </td>
                                            <td>৳ <?php echo e($refill->total_refill_taka); ?></td>
                                            <td>$ <?php echo e($refill->total_refill_dollar); ?></td>
                                            <td>৳ <?php echo e($refill->refill_taka - $refill->refill_usd * $averageRate); ?></td>
                                            <td>$ <?php echo e($refill->adAccount->dollar_rate); ?></td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>

                        </div>

                    </div>
                </div>
            </div>


            <!-- #/ container -->
        </div>
        <!--**********************************
            Content body end
        ***********************************-->


        <!--**********************************
            Footer start
        ***********************************-->
        <?php echo $__env->make('template.home.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--**********************************
            Footer end
        ***********************************-->
    </div>


    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <?php echo $__env->make('template.home.layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\BizMappers_CRM\resources\views/template/home/ad_account_report/show.blade.php ENDPATH**/ ?>